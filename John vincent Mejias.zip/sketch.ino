// Define the LED pins
const int redPin = 8;
const int yellowPin = 9;
const int greenPin = 10;

void setup() {
  // Set all LED pins as OUTPUT
    pinMode(redPin, OUTPUT);
      pinMode(yellowPin, OUTPUT);
        pinMode(greenPin, OUTPUT);
        }

        void loop() {
          // 1. Red Light ON for 5 seconds
            digitalWrite(redPin, HIGH);
              digitalWrite(yellowPin, LOW);
                digitalWrite(greenPin, LOW);
                  delay(5000); // 5000 milliseconds = 5 seconds

                    // 2. Green Light ON for 5 seconds
                      digitalWrite(redPin, LOW);
                        digitalWrite(yellowPin, LOW);
                          digitalWrite(greenPin, HIGH);
                            delay(5000); // 5000 milliseconds = 5 seconds

                              // 3. Yellow Light ON for 2 seconds
                                digitalWrite(redPin, LOW);
                                  digitalWrite(yellowPin, HIGH);
                                    digitalWrite(greenPin, LOW);
                                      delay(2000); // 2000 milliseconds = 2 seconds
                                      }
                                      
